package com.example.bedrockcontrol;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String BEDROCK_PACKAGE = "com.mojang.minecraftpe";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(26), dp(24), dp(20));
        root.setBackgroundColor(Color.rgb(23, 32, 23));

        TextView title = text("BEDROCK CONTROL", 25, Color.WHITE, true);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(64)));
        root.addView(text("مشغّل ماينكرافت بيدروك", 18, Color.rgb(190,225,190), true),
                new LinearLayout.LayoutParams(-1, dp(42)));
        TextView info = text("يفتح اللعبة المثبّتة على هاتفك.\nهذا الإصدار لا يضيف أزرارًا داخل اللعبة تلقائيًا؛ ملفك الحالي إعدادات تحكم وليس تطبيقًا.", 15, Color.WHITE, false);
        info.setPadding(dp(8), dp(12), dp(8), dp(12));
        root.addView(info, new LinearLayout.LayoutParams(-1, dp(110)));

        Button launch = button("▶  افتح Minecraft Bedrock", Color.rgb(46,125,50));
        launch.setOnClickListener(v -> launchBedrock());
        root.addView(launch);

        Button help = button("كيف أفعّل أزرار التحكم؟", Color.rgb(55,71,79));
        help.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("حول أزرار التحكم")
            .setMessage("هذا التطبيق يفتح Minecraft فقط. لا يمكنه تفعيل ملف أزرار خارجي تلقائيًا داخل Bedrock من دون دعم من اللعبة أو أداة متوافقة وصلاحيات إضافية. جرّب إعدادات اللمس من داخل Minecraft.")
            .setPositiveButton("حسنًا", null).show());
        root.addView(help);

        TextView footer = text("الإصدار 1.0 • لا يتضمن اللعبة نفسها", 12, Color.LTGRAY, false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(24);
        root.addView(footer, fp);
        setContentView(root);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(17); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color); bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.rgb(92,145,94));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
        lp.setMargins(0, dp(8), 0, 0); b.setLayoutParams(lp);
        return b;
    }

    private void launchBedrock() {
        PackageManager pm = getPackageManager();
        Intent i = pm.getLaunchIntentForPackage(BEDROCK_PACKAGE);
        if (i != null) {
            try { startActivity(i); return; } catch (Exception ignored) {}
        }
        new AlertDialog.Builder(this)
            .setTitle("لم يتم العثور على Minecraft")
            .setMessage("ثبّت Minecraft Bedrock الرسمية على هاتفك أولًا، ثم افتح هذا التطبيق.")
            .setPositiveButton("فتح صفحة Minecraft", (d,w) ->
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.mojang.minecraftpe"))))
            .setNegativeButton("إغلاق", null).show();
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
