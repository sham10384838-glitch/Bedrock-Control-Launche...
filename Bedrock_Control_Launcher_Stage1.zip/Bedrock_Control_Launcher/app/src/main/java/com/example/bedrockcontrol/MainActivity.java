package com.example.bedrockcontrol;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String BEDROCK_PACKAGE = "com.mojang.minecraftpe";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(26), dp(24), dp(20)); root.setBackgroundColor(Color.rgb(23,32,23));
        root.addView(text("BEDROCK CONTROL",25,Color.WHITE,true), new LinearLayout.LayoutParams(-1,dp(64)));
        root.addView(text("مشغّل ماينكرافت بيدروك • نسخة تجريبية للتحكم",16,Color.rgb(190,225,190),true), new LinearLayout.LayoutParams(-1,dp(54)));
        TextView info=text("المرحلة الأولى: لوحة أزرار عائمة قابلة للسحب مع حفظ المواقع. هذه الأزرار واجهة تجريبية؛ لا ترسل ضغطات فعلية إلى Minecraft بعد.",15,Color.WHITE,false);
        info.setPadding(dp(8),dp(12),dp(8),dp(12)); root.addView(info,new LinearLayout.LayoutParams(-1,dp(130)));
        Button overlay=button("① تفعيل صلاحية الأزرار العائمة",Color.rgb(55,71,79));
        overlay.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}else startOverlay(); }); root.addView(overlay);
        Button launch=button("▶ افتح Minecraft Bedrock",Color.rgb(46,125,50)); launch.setOnClickListener(v->launchBedrock()); root.addView(launch);
        Button stop=button("إيقاف الأزرار العائمة",Color.rgb(100,55,55)); stop.setOnClickListener(v->{stopService(new Intent(this,OverlayService.class));Toast.makeText(this,"تم إيقاف الأزرار العائمة",Toast.LENGTH_SHORT).show();}); root.addView(stop);
        TextView note=text("اسحبي الأزرار بعد تفعيل وضع التعديل داخل اللوحة. المواقع تُحفظ على الهاتف.",13,Color.LTGRAY,false); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(18);root.addView(note,np);
        setContentView(root);
    }
    private void startOverlay(){ if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"فعّلي صلاحية الظهور فوق التطبيقات أولاً",Toast.LENGTH_LONG).show();return;} startService(new Intent(this,OverlayService.class));Toast.makeText(this,"ظهرت لوحة التحكم التجريبية",Toast.LENGTH_SHORT).show(); }
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setAllCaps(false);b.setTextColor(Color.WHITE);GradientDrawable bg=new GradientDrawable();bg.setColor(color);bg.setCornerRadius(dp(16));bg.setStroke(dp(1),Color.rgb(92,145,94));b.setBackground(bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,dp(8),0,0);b.setLayoutParams(lp);return b;}
    private void launchBedrock(){Intent i=getPackageManager().getLaunchIntentForPackage(BEDROCK_PACKAGE);if(i!=null){try{startActivity(i);return;}catch(Exception ignored){}}new AlertDialog.Builder(this).setTitle("لم يتم العثور على Minecraft").setMessage("ثبّت Minecraft Bedrock على هاتفك أولاً.").setPositiveButton("فتح صفحة Minecraft",(d,w)->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id=com.mojang.minecraftpe")))).setNegativeButton("إغلاق",null).show();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
