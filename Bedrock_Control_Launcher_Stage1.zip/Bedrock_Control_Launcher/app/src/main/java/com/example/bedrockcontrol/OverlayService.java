package com.example.bedrockcontrol;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;

public class OverlayService extends Service {
    private WindowManager wm; private LinearLayout panel; private WindowManager.LayoutParams params; private boolean editMode=true; private SharedPreferences prefs;
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);prefs=getSharedPreferences("overlay_positions",MODE_PRIVATE);showPanel();}
    private void showPanel(){
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(8,8,8,8);panel.setBackground(round(Color.argb(180,20,20,20),18));
        TextView header=new TextView(this);header.setText("BEDROCK • وضع التعديل ON");header.setTextColor(Color.WHITE);header.setGravity(Gravity.CENTER);header.setPadding(8,8,8,8);header.setOnClickListener(v->{editMode=!editMode;header.setText("BEDROCK • وضع التعديل "+(editMode?"ON":"OFF"));Toast.makeText(this,editMode?"اسحبي الأزرار لتغيير مواقعها":"وضع اللعب: السحب متوقف",Toast.LENGTH_SHORT).show();});panel.addView(header);
        addControl("MOVE  ◉", "move", 90, 90);addControl("JUMP  ↑", "jump", 88, 52);addControl("ATTACK ⚔", "attack", 100, 52);addControl("MINE ⛏", "mine", 100, 52);addControl("SPRINT ➜", "sprint", 100, 52);
        params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.LEFT;params.x=prefs.getInt("panel_x",30);params.y=prefs.getInt("panel_y",120);wm.addView(panel,params);
        panel.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;public boolean onTouch(View v,MotionEvent e){if(!editMode)return false;switch(e.getAction()){case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;return true;case MotionEvent.ACTION_MOVE:params.x=ox+(int)(e.getRawX()-sx);params.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(panel,params);return true;case MotionEvent.ACTION_UP:prefs.edit().putInt("panel_x",params.x).putInt("panel_y",params.y).apply();return true;}return false;}});
    }
    private void addControl(String label,String key,int w,int h){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(round(Color.argb(220,30,30,30),14));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(w,h);lp.setMargins(3,3,3,3);panel.addView(b,lp);b.setOnClickListener(v->Toast.makeText(this,label+": الواجهة جاهزة، ربط ضغطات اللعبة سيكون في مرحلة لاحقة",Toast.LENGTH_SHORT).show());}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(2,Color.WHITE);return d;}
    @Override public int onStartCommand(Intent i,int flags,int startId){return START_NOT_STICKY;}
    @Override public void onDestroy(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored);}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
